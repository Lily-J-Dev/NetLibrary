A template for the chat room tutorial using netlib.
