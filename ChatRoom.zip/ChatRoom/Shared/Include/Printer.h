#pragma once
#include <mutex>
#include <sstream>

class Printer :
        public std::ostringstream
{

};