#include <iostream>
#include <thread>
#include <Printer.h>
#include "NetClient.h"


void NetClient::connect()
{

}

void NetClient::run()
{
	while (client.IsRunning())
	{
		std::this_thread::sleep_for(std::chrono::milliseconds(10));
	}

	exiting = true;
}

void NetClient::input()
{
    while (!exiting)
    {

    }
}

