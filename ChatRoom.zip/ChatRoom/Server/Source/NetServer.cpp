#include <Printer.h>
#include "NetServer.h"

NetServer::~NetServer()
{

}

void NetServer::start()
{

}

void NetServer::run()
{
	// while server should not terminate
	static bool terminate = false;
	while (!terminate)
	{
		std::this_thread::sleep_for(std::chrono::milliseconds(10));
	}
}