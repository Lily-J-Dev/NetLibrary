#include <memory>
#include "NetServer.h"

int main()
{
  NetServer server;
  server.initialise();
  server.run();
  return 0;
}
