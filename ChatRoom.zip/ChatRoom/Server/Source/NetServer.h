#pragma once
#include "ServerConnection.h"

class NetServer
{
public:
	NetServer() = default;
	~NetServer();

	void initialise();
	void run();
	
private:
    netlib::ServerConnection server;
};